package dk.via.pro3.springiocexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringIocExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringIocExampleApplication.class, args);
    }

}
