package dk.via.pro3.springiocexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIocExampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
